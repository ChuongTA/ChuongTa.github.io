from param import delta_t, inv_hor, C_pv_max, C_bss_max
from param import SOC_i_bss, SOC_min_bss, SOC_max_bss, eff_bss
from param import C_ev, P_nom_ev, eff_ev, SOC_min_ev, SOC_max_ev, SOC_target_ev
from param import PI_gen, PI_imp, PI_exp, PI_c_inv, PI_c_bss, PI_c_pv, PI_c_gen
from pyomo.environ import ConcreteModel, Binary, Param, Var, Objective, Constraint, NonNegativeReals, minimize
from datetime import datetime
import utils
import numpy as np

C_pv = 10                            # PV system size [kWp]
C_bss = 40                           # Battery capacity [kWh]	
P_nom_bss = 10                       # Battery inverter nominal power [kW]
P_nom_pv = 10                        # PV inverter nominal power [kW]
P_max_gen = 10                       # Maximum generator power [kW]

    # Access all parameters present in the res object.
    # These exists for each t in model.t:
    #  - res.P_load[t] = Load power at time t
    #  - res.P_pv_max[t] = Max available PV power at time t [kW/kWp]
    #  - res.EV_connected[t] = EV connected at time t

    # These exists for each c in model.connections:
    #  - res.t_arr[c] = Time at which the EV is connected for the c-th connection
    #  - res.t_dep[c] = Time at which the EV is disconnected for the c-th connection
    #  - res.SOC_i_ev[c] = Initial SOC of the EV connected at time t_arr[c]
    

def create_model(res):
    # Create a concrete model
    model = ConcreteModel()
    
    model.periods = range(res.t_s)
    model.connections = range(len(res.t_arr)) # A set is created with length equal to the number of EV connections

    # 1st Operation planning asset sizes
    model.C_pv = Param(initialize=C_pv)                                    # PV system size [kWp]
    model.P_nom_pv = Param(initialize=P_nom_pv)                            # Nominal power for PV inverter [kW]
    model.C_bss = Param(initialize=C_bss)                                  # Battery capacity [kWh]
    model.P_nom_bss = Param(initialize=P_nom_bss)                          # Battery inverter nominal power [kW]
    model.C_ev = Param(initialize=C_ev)                                    # EV capacity [kWh]
    model.P_nom_ev = Param(initialize=P_nom_ev)                            # EV charger nominal power [kW]
    model.P_max_gen = Param(initialize=P_max_gen)                          # Maximum generator power [kW]



    # 2nd Operational variables 
    model.P_pv = Var(model.periods, within=NonNegativeReals)                # PV power output [kW]

    model.P_charge_bss = Var(model.periods, within=NonNegativeReals)        # Battery charging power [kWh] 
    model.P_discharge_bss = Var(model.periods, within=NonNegativeReals)     # Battery discharging power [kWh]  

    model.P_imp = Var(model.periods, within=NonNegativeReals)               # Import [kW]
    model.P_exp = Var(model.periods, within=NonNegativeReals)               # Export [kW]
    

    model.P_charge_ev = Var(model.periods, within=NonNegativeReals)         # EV charge [kW]
    model.P_discharge_ev = Var(model.periods, within=NonNegativeReals)      # EV discharge [kW]
    
    # Generator output
    model.P_gen = Var(model.periods, within=NonNegativeReals)               # Gen output [W]
    model.gen_status = Var(model.periods, within=Binary)                    # Gen on/off
    
    # Energy storage variables for battery and EV
    model.SOC_bss = Var(model.periods, within=NonNegativeReals)             # Bss state of charge [kWh]
    model.SOC_ev = Var(model.periods, within=NonNegativeReals) 
    # Generator
    # Binary variables for mode control
    model.gen_status = Var(model.periods, within=Binary, initialize=0)     # Indicates if generator is on 


    # Energy storage variables for battery and EV
    model.SOC_bss = Var(model.periods, within=NonNegativeReals)             # Bss state of charge [kWh]
    model.SOC_ev = Var(model.periods, within=NonNegativeReals)              # EV state of charge [kWh]
    
    # Define the objective function 
    # Objective: Minimize net cost
    model.objective = Objective(
        sense=minimize,
        expr=sum(delta_t * (
            PI_gen * model.P_gen[t] +
            PI_imp * model.P_imp[t] -
            PI_exp * model.P_exp[t]
        ) for t in model.periods)
    )

    #Constraints ---------------------------------------------------------------------------------------------------------------------------
    # Power balance constraint:
    # 1st Power balance constraint:
    def power_balance_rule(model, t):
        return (
            model.P_pv[t] + model.P_gen[t] + model.P_discharge_bss[t] + model.P_discharge_ev[t] + model.P_imp[t]
            ==
            res.P_load[t] + model.P_charge_bss[t] + model.P_charge_ev[t] + model.P_exp[t]
        )
    
    model.P_bal_cstr = Constraint(model.periods, rule=power_balance_rule)
    # This will be ensured for all time steps t. You should access variables etc with model.variable_name[t]
    
    #2nd PV power constraint:
    # 2.1. Maximum PV Production Constraint: Checj the size and P_nom_pv (inverter size)
    def pv_size_limit_rule(model, t):
        return model.P_pv[t] <= model.C_pv * res.P_pv_max[t]
    def pv_inverter_limit_rule(model, t):
        return model.P_pv[t] <= model.P_nom_pv * res.P_pv_max[t]
    model.pv_size_limit = Constraint(model.periods, rule=pv_size_limit_rule)
    model.pv_inv_limit = Constraint(model.periods, rule=pv_inverter_limit_rule)

    #3rd Battery Energy constraints
    # 3.1. Battery SOC update constraint
    def SOC_bss_update_rule(model, t):
        if t == 0:
            return model.SOC_bss[t] == res.SOC_bss_i* model.C_bss # Initial SOC
        return  model.SOC_bss[t] ==  model.SOC_bss[t-1] + delta_t * (
                model.P_charge_bss[t-1] * eff_bss - model.P_discharge_bss[t-1] / eff_bss)
    model.SOC_bss_update = Constraint(model.periods, rule=SOC_bss_update_rule)

    # 3.2 Battery SOC limits
    # Battery SOC limits
    model.bss_soc_min = Constraint(model.periods, rule=lambda model, t: model.SOC_bss[t] >= SOC_min_bss * model.C_bss)
    model.bss_soc_max = Constraint(model.periods, rule=lambda model, t: model.SOC_bss[t] <= SOC_max_bss * model.C_bss)

    # 3.3 Battery mode constraints - No charge and discharge at the same time + Limit the power to the inverter size
    model.bss_mode = Var(model.periods, within=Binary) # Binary variable to indicate whether the battery is charging or discharging
    
    def bss_charge_mode_rule(model, t):
        return model.P_charge_bss[t] <= model.bss_mode[t] * model.P_nom_bss
    model.bss_charge_mode = Constraint(model.periods, rule=bss_charge_mode_rule)

    def bss_discharge_mode_rule(model, t):
        return model.P_discharge_bss[t] <= (1 - model.bss_mode[t]) * model.P_nom_bss
    model.bss_discharge_mode = Constraint(model.periods, rule=bss_discharge_mode_rule)

    # 3.5 Avoird flickering of the battery
    # Penalize mode switching to smooth operations
    # Binary switch detection variable
    # model.bss_switch = Var(model.periods, within=Binary)

    # # Constraint for t > 0 only
    # def bss_switch_rule1(model, t):
    #     if t == 0:
    #         return Constraint.Skip
    #     return model.bss_switch[t] >= model.bss_mode[t] - model.bss_mode[t-1]

    # def bss_switch_rule2(model, t):
    #     if t == 0:
    #         return Constraint.Skip
    #     return model.bss_switch[t] >= model.bss_mode[t-1] - model.bss_mode[t]

    # model.bss_switch_diff1 = Constraint(model.periods, rule=bss_switch_rule1)
    # model.bss_switch_diff2 = Constraint(model.periods, rule=bss_switch_rule2)



    # BONUS: EV Constraint
    # 4.1 Create a set of connections (one per EV visit)
    # Define connection index set (one per EV visit) - Initial SOC of the EV connected at time t_arrival[c]
    def ev_initial_soc_rule(model, c):
        t_arrival = res.t_arr[c]
        soc_initial = res.SOC_ev_i[c]
        return model.SOC_ev[t_arrival] == soc_initial
    model.EV_initial_soc_cstr = Constraint(model.connections, rule=ev_initial_soc_rule)
    
    # 4.2 EV SOC update constraint
    def SOC_ev_update_rule(model, t):
        if t == 0 or t in res.t_arr:
            return Constraint.Skip
        if res.EV_connected[t-1] == 1:
            return model.SOC_ev[t] == model.SOC_ev[t-1] + delta_t * (
                model.P_charge_ev[t-1] * eff_ev - model.P_discharge_ev[t-1] / eff_ev
            )
        else:
            return model.SOC_ev[t] == model.SOC_ev[t-1]  # constant when not connected
    model.SOC_ev_update = Constraint(model.periods, rule=SOC_ev_update_rule)

    #4.3 Target SOC must be reached at EV departure
    # Define connection index set (one per EV visit)
    def ev_target_rule(model, c):
            return model.SOC_ev[res.t_dep[c]] >= SOC_target_ev * model.C_ev
    model.EV_target_cstr = Constraint(model.connections, rule=ev_target_rule)


    # 4.4 EV SOC limits (min and max)
    def SOC_ev_min_limit_rule(model, t):
        return model.SOC_ev[t] >= model.C_ev * SOC_min_ev
    model.SOC_ev_min_limit = Constraint(model.periods, rule=SOC_ev_min_limit_rule)
    
    def SOC_ev_max_limit_rule(model, t):
        return model.SOC_ev[t]<= model.C_ev * SOC_max_ev
    model.SOC_ev_max_limit = Constraint(model.periods, rule=SOC_ev_max_limit_rule)
    
    # 4.5 EV charging and discharging limits only when connected + avoid charge/discharge at the same time
    # EV charging power limit when connected
    def ev_ch_limit_rule(model, t):
        if res.EV_connected[t] == 0:
            return model.P_charge_ev[t] == 0
        return model.P_charge_ev[t] <= model.P_nom_ev

    model.ev_ch_limit = Constraint(model.periods, rule=ev_ch_limit_rule)

    # EV discharge power limit when connected
    def ev_dis_limit_rule(model, t):
        if res.EV_connected[t] == 0:
             return model.P_discharge_ev[t] ==0
        #else:res.EV_connected[t] == 1:
        return model.P_discharge_ev[t] <= model.P_nom_ev
    
    model.ev_dis_limit = Constraint(model.periods, rule=ev_dis_limit_rule)

    
    model.ev_mode = Var(model.periods, within=Binary)
    model.ev_ch_excl = Constraint(model.periods, rule=lambda model, t: model.P_charge_ev[t] <= model.ev_mode[t] * model.P_nom_ev)
    model.ev_dis_excl = Constraint(model.periods, rule=lambda model, t: model.P_discharge_ev[t] <= (1 - model.ev_mode[t]) * model.P_nom_ev)


    # 5. Generator power constraints
    #Generator Maximum Power Output Constraint
    model.gen_max = Constraint(model.periods, expr=lambda model, t:model.P_gen[t] <= model.P_max_gen * model.gen_status[t])

    # 6. export power limit
    def export_limit_rule(model, t):
        return model.P_exp[t] <= model.P_pv[t] + model.P_gen[t]
    model.export_limit_cstr = Constraint(model.periods, rule=export_limit_rule)


    return model

      
from datetime import timedelta

# def print_debug_info(results):
#     print("\n=== EV SCHEDULE INFO ===")
#     for i, t in enumerate(results.t_arr):
#         arr_time = results.start_time + timedelta(hours=t * delta_t)
#         dep_time = results.start_time + timedelta(hours=results.t_dep[i] * delta_t)
#         soc_init = results.SOC_ev_i[i]
#         print(f"EV {i+1}: Arrival @ {arr_time}, Departure @ {dep_time}, Initial SOC = {soc_init:.2f} kWh")
        
#     print("=== EV ENERGY REQUIREMENT CHECK ===")
#     for i, (t1, t2) in enumerate(zip(results.t_arr, results.t_dep)):
#         duration = (t2 - t1 + 1) * delta_t
#         soc_needed = SOC_target_ev * C_ev - results.SOC_ev_i[i]
#         required_avg_power = soc_needed / (duration * eff_ev)
#         print(f"EV {i+1}: Needs {soc_needed:.2f} kWh over {duration:.2f}h → avg {required_avg_power:.2f} kW vs max {P_nom_ev} kW")

#     print("\n=== BATTERY INFO ===")
#     print(f"Initial Battery SOC: {results.SOC_bss_i * 100:.1f}% ({results.SOC_bss_i * C_bss_max:.2f} kWh)")
#     print(f"Battery SOC min: {SOC_min_bss * 100:.1f}% ({SOC_min_bss * C_bss_max:.2f} kWh)")
#     print(f"Battery SOC max: {SOC_max_bss * 100:.1f}% ({SOC_max_bss * C_bss_max:.2f} kWh)")


      
def run(model, results):
    # print_debug_info(results)  

    model, results = utils.solve_model(model, results)
    if model and results:
        utils.print_sizing_results(results)
        utils.check_res(results)
        utils.print_res(results, n_days)
        utils.print_pv_res(results, n_days)
        #utils.plot_res2(results) # /!\ Do not use this plotting function to create plots for your report. It is only for interactive visualisation purposes.
    return results

start_time = datetime(2021, 1, 1, 0, 0, 0)                                  # Start time of the simulation [YYYY, MM, DD, HH, MM, SS]
n_days = 5                                                           # Number of days to simulate
results = utils.Results(start_time, n_days, yearly_kwh=4500, yearly_km=15000)      # Initialize results object with start time and number of days, yearly consumption and km driven
model = create_model(results)
run(model, results)
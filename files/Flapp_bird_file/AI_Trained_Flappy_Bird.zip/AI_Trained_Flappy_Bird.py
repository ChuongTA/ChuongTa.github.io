import pygame
import sys
import random
import numpy as np

pygame.mixer.pre_init(frequency=44100, size=-16, channels=2, buffer=512)
pygame.init()

# Global Constraints
WINDOW_WIDTH = 900
WINDOW_HEIGHT = 600
FLOOR_Y = 512
BIRD_X_POS = 50
PIPE_SPACING = 350
GAME_SPEED = 6

screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Flappy Bird AI")
clock = pygame.time.Clock()
game_font = pygame.font.Font(None, 35)
score_font = pygame.font.Font(None, 50)
menu_font = pygame.font.Font(None, 60)

# Loading Assets
# Background
background = pygame.image.load('assess/background-night.png').convert()
background = pygame.transform.scale(background, (WINDOW_WIDTH, WINDOW_HEIGHT))

# Floor
floor_img = pygame.image.load('assess/floor.png').convert()
floor_img = pygame.transform.scale(floor_img, (WINDOW_WIDTH, 100))

# Bird Animation Frames
bird_down = pygame.image.load('assess/yellowbird-downflap.png').convert_alpha()
bird_mid = pygame.image.load('assess/yellowbird-midflap.png').convert_alpha()
bird_up = pygame.image.load('assess/yellowbird-upflap.png').convert_alpha()
bird_list = [bird_down, bird_mid, bird_up]

# Pipes (Scaled and Flipped)
PIPE_IMG = pygame.image.load('assess/pipe-green.png').convert_alpha()
PIPE_IMG = pygame.transform.scale(PIPE_IMG, (70, 800)) # Scale tall to avoid stretching
PIPE_IMG_FLIPPED = pygame.transform.flip(PIPE_IMG, False, True) # Flip for top pipe

# Artificial Neural Network
class NeuralNetwork:
    def __init__(self, layer_sizes=[5, 8, 1]):
        self.weights = []
        self.biases = []
        for i in range(len(layer_sizes) - 1):
            std_dev = np.sqrt(2.0 / (layer_sizes[i] + layer_sizes[i+1]))
            w = np.random.randn(layer_sizes[i], layer_sizes[i+1]) * std_dev
            b = np.zeros((1, layer_sizes[i+1]))
            self.weights.append(w)
            self.biases.append(b)
    
    def forward(self, x):
        x = np.tanh(np.dot(x, self.weights[0]) + self.biases[0])
        x = np.dot(x, self.weights[1]) + self.biases[1]
        return (1 / (1 + np.exp(-x)))[0][0] > 0.5
    
    def mutate(self, mutation_rate=0.1):
        for i in range(len(self.weights)):
            if np.random.random() < mutation_rate:
                mask = np.random.random(self.weights[i].shape) < 0.2
                noise = np.random.randn(*self.weights[i].shape) * 0.5
                self.weights[i][mask] += noise[mask]
            if np.random.random() < mutation_rate:
                mask = np.random.random(self.biases[i].shape) < 0.2
                noise = np.random.randn(*self.biases[i].shape) * 0.5
                self.biases[i][mask] += noise[mask]
    
    def copy(self):
        nn = NeuralNetwork([5, 8, 1])
        nn.weights = [w.copy() for w in self.weights]
        nn.biases = [b.copy() for b in self.biases]
        return nn

# Agent/Player
class Agent:
    def __init__(self):
        self.brain = NeuralNetwork()
        self.fitness = 0
        self.alive = True
        self.y = 250
        self.vel = 0
        self.rect = pygame.Rect(BIRD_X_POS, 250, 30, 24)
        self.score = 0
    
    def think(self, bird_y, bird_vel, pipe_gap_top, pipe_gap_bottom, pipe_dist):
        inputs = np.array([[
            bird_y / WINDOW_HEIGHT,
            bird_vel / 20,
            pipe_gap_top / WINDOW_HEIGHT,
            pipe_gap_bottom / WINDOW_HEIGHT,
            pipe_dist / WINDOW_WIDTH
        ]])
        return self.brain.forward(inputs)
    
    def flap(self):
        self.vel = -9
    
    def copy(self):
        agent = Agent()
        agent.brain = self.brain.copy()
        return agent

# Pipe
class Pipe:
    width = 70
    opening = 160
    
    def __init__(self, x):
        self.x = x
        self.passed = False
        safe_zone = 50
        min_gap_y = safe_zone
        max_gap_y = FLOOR_Y - safe_zone - self.opening
        self.gap_y = random.randint(min_gap_y, max_gap_y)
        self.bottom_y = self.gap_y + self.opening
        self.top_height = self.gap_y
        self.bottom_height = FLOOR_Y - self.bottom_y

    def update(self):
        self.x -= GAME_SPEED

    def draw(self, screen):
        # Draw Top Pipe (Flipped)
        if self.top_height > 0:
            visible_h = int(self.top_height)
            # Crop from bottom of flipped image
            rect_area = (0, PIPE_IMG_FLIPPED.get_height() - visible_h, self.width, visible_h)
            screen.blit(PIPE_IMG_FLIPPED.subsurface(rect_area), (self.x, 0))
            
        # Draw Bottom Pipe (Normal)
        if self.bottom_height > 0:
            visible_h = int(self.bottom_height)
            # Crop from top of normal image
            rect_area = (0, 0, self.width, visible_h)
            screen.blit(PIPE_IMG.subsurface(rect_area), (self.x, self.bottom_y))

    def collides(self, rect):
        top_rect = pygame.Rect(self.x, 0, self.width, self.top_height)
        bottom_rect = pygame.Rect(self.x, self.bottom_y, self.width, self.bottom_height)
        return rect.colliderect(top_rect) or rect.colliderect(bottom_rect)

def draw_floor(x):
    screen.blit(floor_img, (x, FLOOR_Y))
    screen.blit(floor_img, (x + WINDOW_WIDTH, FLOOR_Y))

# Mode 1: Manual Play
def play_manually():
    player = Agent()
    pipes = [Pipe(WINDOW_WIDTH + 100)]
    floor_x = 0
    score = 0
    running = True
    bird_anim_timer = 0
    bird_img_idx = 0
    
    while running:
        clock.tick(60)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    player.flap()
                if event.key == pygame.K_ESCAPE:
                    return

        # Mechanics
        player.vel += 0.7
        player.y += player.vel
        player.rect.y = int(player.y)
        
        if player.y >= FLOOR_Y - 24 or player.y < 0:
            running = False

        if WINDOW_WIDTH - pipes[-1].x > PIPE_SPACING:
            pipes.append(Pipe(WINDOW_WIDTH))
            
        for pipe in pipes:
            pipe.update()
            if pipe.collides(player.rect):
                running = False
            
            if not pipe.passed and pipe.x + pipe.width < BIRD_X_POS:
                pipe.passed = True
                score += 1
                
        if pipes[0].x < -pipes[0].width:
            pipes.pop(0)

        # Drawing
        screen.blit(background, (0, 0))
        for pipe in pipes:
            pipe.draw(screen)
            
        floor_x -= GAME_SPEED
        draw_floor(floor_x)
        if floor_x <= -WINDOW_WIDTH: floor_x = 0
        
        # Draw Bird
        bird_anim_timer += 1
        if bird_anim_timer > 5:
            bird_img_idx = (bird_img_idx + 1) % 3
            bird_anim_timer = 0
        
        rot_bird = pygame.transform.rotate(bird_list[bird_img_idx], -player.vel * 2)
        screen.blit(rot_bird, player.rect)
            
        screen.blit(score_font.render(f"Score: {score}", True, (255, 255, 255)), (20, 20))
        pygame.display.flip()

    # Game Over Screen
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    play_manually()
                    return
                if event.key == pygame.K_m:
                    return

        overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
        overlay.set_alpha(3)
        overlay.fill((0,0,0))
        screen.blit(overlay, (0,0))
        
        screen.blit(game_font.render("GAME OVER", True, (255, 50, 50)), (WINDOW_WIDTH//2 - 70, WINDOW_HEIGHT//2 - 50))
        screen.blit(game_font.render(f"Final Score: {score}", True, (255, 255, 255)), (WINDOW_WIDTH//2 - 80, WINDOW_HEIGHT//2))
        screen.blit(game_font.render("Press SPACE to Restart or M for Menu", True, (200, 200, 200)), (WINDOW_WIDTH//2 - 200, WINDOW_HEIGHT//2 + 50))
        pygame.display.flip()

# Mode 2: AI Evolution
def run_generation(population, gen_num, global_high_score):
    for agent in population:
        agent.alive = True
        agent.fitness = 0
        agent.score = 0
        agent.y = 250
        agent.vel = 0
        agent.rect.y = 250

    pipes = [Pipe(WINDOW_WIDTH + 100)] 
    floor_x = 0
    best_score_gen = 0
    bird_anim_timer = 0
    bird_img_idx = 0
    
    running = True
    while running and any(a.alive for a in population):
        clock.tick(60)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE: return None, 0

        if WINDOW_WIDTH - pipes[-1].x > PIPE_SPACING:
            pipes.append(Pipe(WINDOW_WIDTH))

        for pipe in pipes:
            pipe.update()
        
        if pipes[0].x < -pipes[0].width:
            pipes.pop(0)

        for pipe in pipes:
            if not pipe.passed and pipe.x + pipe.width < BIRD_X_POS:
                pipe.passed = True
                for agent in population:
                    if agent.alive:
                        agent.score += 1
                        agent.fitness += 10
                        if agent.score > best_score_gen:
                            best_score_gen = agent.score

        closest_pipe = None
        for pipe in pipes:
            if pipe.x + pipe.width > BIRD_X_POS:
                closest_pipe = pipe
                break
        
        p_gap_top = 0
        p_gap_bot = FLOOR_Y
        p_dist = WINDOW_WIDTH
        if closest_pipe:
            p_gap_top = closest_pipe.gap_y
            p_gap_bot = closest_pipe.bottom_y
            p_dist = closest_pipe.x - BIRD_X_POS

        alive_count = 0
        for agent in population:
            if not agent.alive: continue
            
            alive_count += 1
            agent.fitness += 0.1
            
            should_flap = agent.think(agent.y, agent.vel, p_gap_top, p_gap_bot, p_dist)
            if should_flap and agent.vel > -5:
                agent.vel = -9
            
            agent.vel += 0.7
            agent.y += agent.vel
            agent.rect.y = int(agent.y)
            
            if agent.y >= FLOOR_Y - 24 or agent.y < 0:
                agent.alive = False
            
            for pipe in pipes:
                if pipe.collides(agent.rect):
                    agent.alive = False

        # Drawing
        screen.blit(background, (0, 0))
        for pipe in pipes: pipe.draw(screen)
        floor_x -= GAME_SPEED
        draw_floor(floor_x)
        if floor_x <= -WINDOW_WIDTH: floor_x = 0
            
        bird_anim_timer += 1
        if bird_anim_timer > 5:
            bird_img_idx = (bird_img_idx + 1) % 3
            bird_anim_timer = 0
            
        for agent in population:
            if agent.alive:
                rot_bird = pygame.transform.rotate(bird_list[bird_img_idx], -agent.vel * 2)
                screen.blit(rot_bird, agent.rect)

        # UI Overlay
        ui_bg = pygame.Surface((250, 150))
        ui_bg.set_alpha(150)
        ui_bg.fill((0,0,0))
        screen.blit(ui_bg, (10, 10))
        screen.blit(game_font.render(f"Gen: {gen_num}", True, (255, 255, 255)), (20, 20))
        screen.blit(game_font.render(f"Alive: {alive_count}", True, (0, 255, 0)), (20, 50))
        screen.blit(score_font.render(f"Score: {best_score_gen}", True, (255, 215, 0)), (20, 80))
        screen.blit(game_font.render(f"Best Ever: {global_high_score}", True, (0, 191, 255)), (20, 120))
        screen.blit(game_font.render("ESC to Menu", True, (200, 200, 200)), (20, 560))

        pygame.display.flip()
        
        if alive_count == 0:
            running = False
            
    return population, best_score_gen

def evolve(generations=1000):
    population = [Agent() for _ in range(150)]
    global_high_score = 0
    
    for gen in range(1, generations + 1):
        population, score_this_gen = run_generation(population, gen, global_high_score)
        
        if population is None: # User pressed ESC
            return

        if score_this_gen > global_high_score:
            global_high_score = score_this_gen
        
        population.sort(key=lambda x: x.fitness, reverse=True)
        
        new_pop = []
        for i in range(10): new_pop.append(population[i].copy())
        while len(new_pop) < len(population):
            parent = random.choice(population[:30])
            child = parent.copy()
            child.brain.mutate(0.15)
            new_pop.append(child)
        population = new_pop

# main menu
def main_menu():
    while True:
        screen.blit(background, (0,0))
        
        title = menu_font.render("FLAPPY BIRD AI", True, (255, 255, 255))
        title_rect = title.get_rect(center=(WINDOW_WIDTH/2, 150))
        screen.blit(title, title_rect)
        
        btn1 = game_font.render("1. Play Manual (Space)", True, (100, 255, 100))
        btn2 = game_font.render("2. Watch AI Play", True, (100, 200, 255))
        btn3 = game_font.render("3. Quit", True, (255, 100, 100))
        
        screen.blit(btn1, (WINDOW_WIDTH/2 - 120, 250))
        screen.blit(btn2, (WINDOW_WIDTH/2 - 120, 300))
        screen.blit(btn3, (WINDOW_WIDTH/2 - 120, 350))
        
        pygame.display.flip()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    play_manually()
                if event.key == pygame.K_2:
                    evolve()
                if event.key == pygame.K_3:
                    pygame.quit(); sys.exit()

if __name__ == "__main__":
    main_menu()